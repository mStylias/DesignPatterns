package com.StyleM;

public interface PasswordClient {
    void alarm();
    void setPasswordProtector(PasswordProtector protector);
}
