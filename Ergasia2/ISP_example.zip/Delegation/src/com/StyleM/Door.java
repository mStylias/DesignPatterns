package com.StyleM;

public interface Door {
    boolean open();
    void lock();
    boolean unlock(String code);
}
